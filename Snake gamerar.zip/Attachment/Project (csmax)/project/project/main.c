#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "ledmatrix7219d88/ledmatrix7219d88.h"
#define F_CPU 8000000

#define	LCD_DPRT  PORTA 	//LCD DATA PORT
#define	LCD_DDDR  DDRA 		//LCD DATA DDR
#define	LCD_DPIN  PINA 		//LCD DATA PIN
#define	LCD_CPRT  PORTB 	//LCD COMMANDS PORT
#define	LCD_CDDR  DDRB 		//LCD COMMANDS DDR
#define	LCD_CPIN  PINB 		//LCD COMMANDS PIN
#define	LCD_RS  0 			//LCD RS
#define	LCD_RW  1 			//LCD RW
#define	LCD_EN  2 			//LCD EN


void delay_ms(uint16_t d)
{
	uint16_t i;
	for (i = 0; i < d/10; ++i)
	{
		_delay_ms(1);
	}
}

void lcdCommand( unsigned char cmnd )
{
	LCD_DPRT = cmnd & 0xF0;	//Send high nibble to D4-D7
	LCD_CPRT &= ~ (1<<LCD_RS);	//RS = 0 for command
	LCD_CPRT &= ~ (1<<LCD_RW);	//RW = 0 for write
	LCD_CPRT |= (1<<LCD_EN);	//EN = 1 for H-to-L pulse
	_delay_us(1);				//make EN pulse wider
	LCD_CPRT &= ~ (1<<LCD_EN);	//EN = 0 for H-to-L pulse
	_delay_us(100);			//wait
	LCD_DPRT = cmnd<<4;		//Send low nibble to D4-D7
	LCD_CPRT |= (1<<LCD_EN);	//EN = 1 for H-to-L pulse
	_delay_us(1);				//make EN pulse wider
	LCD_CPRT &= ~ (1<<LCD_EN);	//EN = 0 for H-to-L pulse
	_delay_us(100);			//wait
}

void lcdData( unsigned char data )
{
	LCD_DPRT = data & 0xF0;	//Send high nibble to D4-D7
	LCD_CPRT |= (1<<LCD_RS);	//RS = 1 for data
	LCD_CPRT &= ~ (1<<LCD_RW);	//RW = 0 for write
	LCD_CPRT |= (1<<LCD_EN);	//EN = 1 for H-to-L pulse
	_delay_us(1);				//make EN pulse wider
	LCD_CPRT &= ~ (1<<LCD_EN);	//EN = 0 for H-to-L pulse
	LCD_DPRT = data<<4;		//Send low nibble to D4-D7
	LCD_CPRT |= (1<<LCD_EN);	//EN = 1 for H-to-L pulse
	_delay_us(1);				//make EN pulse wider
	LCD_CPRT &= ~ (1<<LCD_EN);	//EN = 0 for H-to-L pulse
	_delay_us(100);			//wait
}

void lcd_init()
{
	LCD_DDDR = 0xFF;
	LCD_CDDR = 0xFF;
	LCD_CPRT &=~(1<<LCD_EN);	//LCD_EN = 0
	lcdCommand(0x33);			//send $33 for init.
	lcdCommand(0x32);			//send $32 for init
	lcdCommand(0x28);			//init. LCD 2 line,5*7 matrix
	lcdCommand(0x0e);			//display on, cursor on
	lcdCommand(0x01);			//clear LCD
	_delay_us(2000);
	lcdCommand(0x06);			//Shift cursor right
}

void lcd_gotoxy(unsigned char x, unsigned char y)
{
	unsigned char firstCharAdr[]={0x80,0xC0,0x94,0xD4} ;
	lcdCommand(firstCharAdr[y-1] + x - 1);
	_delay_us(100);
}

void lcd_print(char *str )
{	char j;
	
	for (j=0;j<strlen(str);j++)
	lcdData(str[j]);
}

void go_on(int st, int en, uint8_t ledmatrix, int move)
{
	ledmatrix7219d88_setledoff(ledmatrix, en);
	ledmatrix7219d88_setledon(ledmatrix, st+move);
}

int game_over(int move, int st, uint8_t ledmatrix)
{
	if ((move == 1) & (st == 8 | st == 16 | st == 24 | st == 32 | st == 40 | st == 48 | st == 56 | st == 64))
	{
		return 1;
	}
	else if ((move == -1) & (st == -1 | st == 7 | st == 15 | st == 23 | st == 31 | st == 39 | st == 47 | st == 55))
	{
		return 1;;
	}
	else if ((move == -8) & (st == -8 | st == -7 | st == -6 | st == -5 | st == -4 | st == -3 | st == -2 | st == -1))
	{
		return 1;
	}
	else if ((move == 8) & (st == 64 | st == 65 | st == 66 | st == 67 | st == 68 | st == 69 | st == 70 | st == 71))
	{
		return 1;
	}
	return 0;
}

int sevense[10] = {63,6,91,79,102,109,125,7,127,103};
int win=0;
void score_7seg(int score)
{
	PORTC = ~sevense[score%10];
	int y;
	char buffer[100];
	if (score == 10)
	{
		lcdCommand(0x01);
		lcd_gotoxy(1,1);
		lcd_print("     Ten");
		lcd_gotoxy(1,2);
		lcd_print(" Nice job!");
	}
	else if (score == 20)
	{
		lcdCommand(0x01);
		lcd_gotoxy(1,1);
		lcd_print("     Twenty");
		lcd_gotoxy(1,2);
		lcd_print(" Move on...");
	}
	else if (score == 30)
	{
		lcdCommand(0x01);
		lcd_gotoxy(1,1);
		lcd_print("     Thirty");
		lcd_gotoxy(1,2);
		lcd_print(" Legend");
	}
	else if (score == 40)
	{
		lcdCommand(0x01);
		lcd_gotoxy(1,1);
		lcd_print("     Forty");
		lcd_gotoxy(1,2);
		lcd_print(" Perfect");
	}
	else if (score == 50)
	{
		lcdCommand(0x01);
		lcd_gotoxy(1,1);
		lcd_print("     Fifty");
		lcd_gotoxy(1,2);
		lcd_print(" You won!");
		win = 1;
	}
}


int main(void)
{
	TCCR0 = (1<<CS02) | (1<<CS00);
	int y;
	char buffer[100];
	lcd_init();
	lcd_gotoxy(1,1);
	lcd_print("level:");
	lcd_gotoxy(11,1);
	y= 1;
	itoa(y,buffer,10);
	lcd_print(buffer);
	lcd_print(")left");
	lcd_gotoxy(1,2);
	y= 2;
	itoa(y,buffer,10);
	lcd_print(buffer);
	lcd_print(")up");
	lcd_gotoxy(10,2);
	y= 3;
	itoa(y,buffer,10);
	lcd_print(buffer);
	lcd_print(")right");
	
	int level;
	DDRB &= 0x0F;
	PORTB |= 0xF0;
	DDRD &= 0x3C;
	PORTD |= 0xC3;
	while(1)
	{
		if ((PIND & 0xC3) == 0x83)
		{
			lcdCommand(0x01);			//clear LCD
			lcd_gotoxy(1,1);
			lcd_print("     Hard Mode");
			_delay_ms(1500);
			lcdCommand(0x01);			//clear LCD
			level = 1;
			break;
		}
		else if((PIND & 0xC3) == 0xC1)
		{
			lcdCommand(0x01);			//clear LCD
			lcd_gotoxy(1,1);
			lcd_print("     Normal Mode");
			_delay_ms(1500);
			lcdCommand(0x01);			//clear LCD
			level = 2;
			break;
		}
		else if((PIND & 0xC3) == 0x43)
		{
			lcdCommand(0x01);			//clear LCD
			lcd_gotoxy(1,1);
			lcd_print("     Easy Mode");
			_delay_ms(1500);
			lcdCommand(0x01);			//clear LCD
			level = 4;
			break;
		}
	}
	lcd_gotoxy(1,1);
	lcd_print("     Enjoy...");
	_delay_ms(1500);
	long delay_level = 1000*level;
	
	
	//init ledmatrix
	ledmatrix7219d88_init();
	uint8_t ledmatrix;
	ledmatrix = 0;
	ledmatrix7219d88_setledon(ledmatrix, 12);
	ledmatrix7219d88_setledon(ledmatrix, 21);
	ledmatrix7219d88_setledon(ledmatrix, 30);
	ledmatrix7219d88_setledon(ledmatrix, 38);
	ledmatrix7219d88_setledon(ledmatrix, 45);
	ledmatrix7219d88_setledon(ledmatrix, 52);
	ledmatrix7219d88_setledon(ledmatrix, 18);
	ledmatrix7219d88_setledon(ledmatrix, 42);
	DDRD |= 0x20;
	for (int q=0; q<3; q++)
	{
		for (int w=0; w<3; w++)
		{
			PORTD |= 0x20;
			_delay_ms(100);
			PORTD &= 0xDF;
			_delay_ms(100);
		}
	}
	_delay_ms(1500);
	for (int i=0; i<=63; i++)
	{
		ledmatrix7219d88_setledoff(ledmatrix, i);
	}
	
	int move; //down=1   up=-1   right=8   left=-8
	int en = 7;
	int md = 15;
	int st = 23;
	ledmatrix7219d88_setledon(ledmatrix, st);
	ledmatrix7219d88_setledon(ledmatrix, md);
	ledmatrix7219d88_setledon(ledmatrix, en);
	delay_ms(delay_level);
	int food;
	int score;
	int ledfood=0;
	uint8_t seed =0;
	for (int i=0; i<100; i++)
	{
		seed += TCNT0;
	}
	srand(seed);
	food = rand()%64;
	for (;food==md | food==en;)
	{
		food = rand()%64;
	}
	ledmatrix7219d88_setledon(ledmatrix, food);
	DDRC = 0xFF;
	PORTC = ~sevense[0];
	
	while (1)
	{
		//food
		if (st == food)
		{
			score++;
			PORTD |= 0x20;
			_delay_ms(10);
			PORTD &= 0xDF;
			score_7seg(score);
			if (win==1)
			{
				break;
			}
			ledmatrix7219d88_setledoff(ledmatrix, food);
			ledmatrix7219d88_setledon(ledmatrix, st);
			food = rand()%64;
			for (;food==md | food==en;)
			{
				food = rand()%64;
			}
			ledmatrix7219d88_setledon(ledmatrix, food);
		}
		
		//movement mode
		int move = st-md;
		
		//game over
		if (game_over(move, st, ledmatrix) == 1)
		{
			break;
		}
		
		//init game & control
		if ((PIND & 0xC3) == 0xC2)
		{
			//_delay_ms(100);
			st = st+1;
			move = st-md;
			ledmatrix7219d88_setledoff(ledmatrix, en);
			ledmatrix7219d88_setledon(ledmatrix, st);
			delay_ms(delay_level);
			en = md;
			md = st-1;
		}
		else if ((PIND & 0xC3) == 0xC1)
		{
			//_delay_ms(100);
			st = st-1;
			move = st-md;
			ledmatrix7219d88_setledoff(ledmatrix, en);
			ledmatrix7219d88_setledon(ledmatrix, st);
			delay_ms(delay_level);
			en = md;
			md = st+1;
		}
		else if ((PIND & 0xC3) == 0x83)
		{
			//_delay_ms(100);
			st = st+8;
			move = st-md;
			ledmatrix7219d88_setledoff(ledmatrix, en);
			ledmatrix7219d88_setledon(ledmatrix, st);
			delay_ms(delay_level);
			en = md;
			md = st-8;
		}
		else if ((PIND & 0xC3) == 0x43)
		{
			//_delay_ms(100);
			st = st-8;
			move = st-md;
			ledmatrix7219d88_setledoff(ledmatrix, en);
			ledmatrix7219d88_setledon(ledmatrix, st);
			delay_ms(delay_level);
			en = md;
			md = st+8;
		}
		else
		{
			go_on(st, en, ledmatrix, move);
			delay_ms(delay_level);
			en = md;
			md = st;
			st = st+move;
		}
	}
	
	
	for (int i=0; i<=63; i++)
	{
		ledmatrix7219d88_setledoff(ledmatrix, i);
	}

	if (win==0)
	{
		lcdCommand(0x01);
		lcd_gotoxy(1,1);
		lcd_print("     Game Over ");
		lcd_gotoxy(1,2);
		lcd_print("Score: ");
		y= score;
		itoa(y,buffer,10);
		lcd_print(buffer);
	}
	else
	{
		ledmatrix7219d88_setledon(ledmatrix, 12);
		ledmatrix7219d88_setledon(ledmatrix, 21);
		ledmatrix7219d88_setledon(ledmatrix, 30);
		ledmatrix7219d88_setledon(ledmatrix, 38);
		ledmatrix7219d88_setledon(ledmatrix, 45);
		ledmatrix7219d88_setledon(ledmatrix, 52);
		ledmatrix7219d88_setledon(ledmatrix, 18);
		ledmatrix7219d88_setledon(ledmatrix, 42);
	}
	
	for (int q=0; q<3; q++)
	{
		for (int w=0; w<3; w++)
		{
			PORTD |= 0x20;
			_delay_ms(100);
			PORTD &= 0xDF;
			_delay_ms(100);
		}
	}
}
